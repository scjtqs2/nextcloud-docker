OC.L10N.register(
    "files_rightclick",
    {
    "Share " : "Megosztás",
    "Select" : "Válassz",
    "Right click" : "Jobb gomb"
},
"nplurals=2; plural=(n != 1);");

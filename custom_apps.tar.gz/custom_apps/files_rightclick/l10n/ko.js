OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "선택 해제",
    "Share " : "공유",
    "Select" : "선택",
    "Copied !" : "복사되었습니다!",
    "Right click" : "오른쪽 클릭",
    "Right click menu for Nextcloud" : "Nextcloud의 오른쪽 클릭 메뉴",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "이 앱은 사용자와 개발자에게 오른쪽 클릭 메뉴를 제공합니다. RightClick 객체를 사용하여 콘텍스트 메뉴를 쉽게 만들 수 있습니다. 파일 앱에서 파일이나 폴더를 마우스 오른쪽 단추로 클릭했을 때 동작 메뉴를 표시합니다."
},
"nplurals=1; plural=0;");

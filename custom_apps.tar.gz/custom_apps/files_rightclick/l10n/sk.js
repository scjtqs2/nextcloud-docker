OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Zrušiť výber",
    "Share " : "Sprístupniť",
    "Select" : "Vybrať",
    "Copied !" : "Skopírované!",
    "Right click" : "Pravý klik",
    "Right click menu for Nextcloud" : "Ponuka pravého kliku pre Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Táto apka umožňuje používateľom a vývojárom mať ponuku pravého kliku. Jednoducho použite objekt RightClick na rýchle vytváranie kontextových ponúk. Apka Súbory už ukazuje ponuku akcií po kliknutí pravým tlačítkom na súbory alebo priečinky."
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");

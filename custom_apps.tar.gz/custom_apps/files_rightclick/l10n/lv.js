OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Noņemt atlasi",
    "Share " : "Koplietot",
    "Select" : "Atlasīt",
    "Copied !" : "Nokopēts!",
    "Right click" : "Labais peles klikšķis",
    "Right click menu for Nextcloud" : "Nextcloud labā klikšķa izvēlne",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Šī lietotne lietotājiem un izstrādātājiem ļauj veikt labo klikšķi. Vienkārši izmantojiet objektu RightClick, lai ātri izveidotu kontekstizvēlnes. Programma Faili jau parāda darbību izvēlni, noklikšķinot ar peles labo pogu uz failiem un mapēm."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");

OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Odstrani izbor",
    "Share " : "Omogoči souporabo",
    "Select" : "Izberi",
    "Copied !" : "Kopirano!",
    "Right click" : "Desni klik",
    "Right click menu for Nextcloud" : "Meni desnega klika za Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Program omogoča uporabnikom in razvijalcem uporabo menija desnega klika miške. Z enostavno uporabo predmeta desnega klika, je mogoče ustvariti vsebinski meni. Program Datoteke meni že podpira z desnim klikom na datoteke in mape."
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");

OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Settings" : "ಆಯ್ಕೆ",
    "Enable" : "ಸಕ್ರಿಯಗೊಳಿಸು",
    "Disable" : "﻿ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");

OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Batal",
    "Settings" : "Tetapan",
    "Enable" : "Aktif",
    "Disable" : "Nyahaktif"
},
"nplurals=1; plural=0;");

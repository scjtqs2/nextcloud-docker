OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Откажи",
    "Confirm" : "Потврди",
    "Settings" : "Параметри",
    "Enable" : "Овозможи",
    "Disable" : "Оневозможи"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");

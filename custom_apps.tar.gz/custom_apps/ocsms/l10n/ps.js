OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "پرېښول",
    "Settings" : "سمونې",
    "Enable" : "فعالول"
},
"nplurals=2; plural=(n != 1);");

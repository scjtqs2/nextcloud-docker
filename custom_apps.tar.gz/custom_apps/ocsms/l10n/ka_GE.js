OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "ტელეფონის სინქრონიზაცია",
    "Cancel" : "უარყოფა",
    "Confirm" : "დადასტურება",
    "Settings" : "პარამეტრები",
    "Label" : "ლეიბლი",
    "Enable" : "ჩართვა",
    "Disable" : "გამორთვა"
},
"nplurals=2; plural=(n!=1);");

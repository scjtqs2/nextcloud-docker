OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "strika",
    "Enable" : "Gilda"
},
"nplurals=2; plural=(n != 1);");

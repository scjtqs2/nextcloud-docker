OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Tālruņa sinhronizēšana",
    "Cancel" : "Atcelt",
    "Confirm" : "Apstiprināt",
    "Settings" : "Iestatījumi",
    "Label" : "Apzīmējums",
    "Enable" : "Iespējo",
    "Disable" : "Deaktivēt"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");

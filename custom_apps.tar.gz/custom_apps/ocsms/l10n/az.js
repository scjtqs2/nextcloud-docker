OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Dayandır",
    "Settings" : "Quraşdırmalar",
    "Enable" : "İşə sal",
    "Disable" : "Dayandır"
},
"nplurals=2; plural=(n != 1);");

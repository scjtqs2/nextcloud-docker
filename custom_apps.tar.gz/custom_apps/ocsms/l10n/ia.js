OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Synchronisation del Telephono",
    "Cancel" : "Cancellar",
    "Confirm" : "Confirmar",
    "Settings" : "Configurationes",
    "Enable" : "Activar",
    "Disable" : "Disactivar"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Phone Sync",
    "Cancel" : "Membatalkan",
    "Confirm" : "Konfirmasi",
    "Settings" : "Setelan",
    "Enable" : "aktifkan",
    "Disable" : "Nonaktifkan"
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Foonsinchronisering",
    "Cancel" : "Kanselleer",
    "Confirm" : "Bevestig",
    "Settings" : "Instellings",
    "Label" : "Etiket",
    "Enable" : "Aktiveer",
    "Disable" : "Deaktiveer"
},
"nplurals=2; plural=(n != 1);");

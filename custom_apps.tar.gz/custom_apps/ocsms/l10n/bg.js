OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Синхронизиране на телефона",
    "Cancel" : "Отказ",
    "Confirm" : "Потвърди",
    "Settings" : "Настройки",
    "Label" : "Име",
    "Enable" : "Включване",
    "Disable" : "Изключване"
},
"nplurals=2; plural=(n != 1);");

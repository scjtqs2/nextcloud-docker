OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Telefon Synkronisering",
    "Cancel" : "Avbryt",
    "Settings" : "Instillingar",
    "Enable" : "Slå på",
    "Disable" : "Slå av"
},
"nplurals=2; plural=(n != 1);");

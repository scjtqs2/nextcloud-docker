OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "ընդհատել",
    "Settings" : "կարգավորումներ"
},
"nplurals=2; plural=(n != 1);");

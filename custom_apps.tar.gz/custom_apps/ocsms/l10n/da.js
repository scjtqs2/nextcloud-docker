OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Telefon sync",
    "Cancel" : "Annullér",
    "Confirm" : "Bekræft",
    "Settings" : "Indstillinger",
    "Label" : "Mærkat",
    "Notification settings" : "Meddelelsesindstillinger",
    "Enable" : "Aktivér",
    "Disable" : "Deaktiver"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Sinkronizimi i celularit",
    "Cancel" : "Anullo",
    "Confirm" : "Konfirmo",
    "Settings" : "Rregullimet",
    "Label" : "Etiketa.",
    "Enable" : "Aktivizo",
    "Disable" : "Çaktivizoje"
},
"nplurals=2; plural=(n != 1);");

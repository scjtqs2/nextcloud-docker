OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Ofbriechen",
    "Settings" : "Astellungen",
    "Enable" : "Aschalten",
    "Disable" : "Ofschalten"
},
"nplurals=2; plural=(n != 1);");

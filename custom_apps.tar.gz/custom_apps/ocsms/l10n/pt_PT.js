OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Sincronização de Telemóvel",
    "Cancel" : "Cancelar",
    "Confirm" : "Confirmar",
    "Settings" : "Definições",
    "Label" : "Legenda",
    "Notification settings" : "Definições de notificação",
    "Enable" : "Ativar",
    "Disable" : "Desativar"
},
"nplurals=2; plural=(n != 1);");

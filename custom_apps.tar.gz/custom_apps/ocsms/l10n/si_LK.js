OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "අවලංගු කරන්න",
    "Settings" : "සැකසුම්",
    "Enable" : "සක්‍රිය කරන්න",
    "Disable" : "අක්‍රිය කරන්න"
},
"nplurals=2; plural=(n != 1);");

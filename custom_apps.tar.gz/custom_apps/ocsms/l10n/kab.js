OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Sefsex",
    "Settings" : "Iɣewwaṛen"
},
"nplurals=2; plural=(n != 1);");

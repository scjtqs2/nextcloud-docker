OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Sincronización de teléfonu",
    "Cancel" : "Encaboxar",
    "Confirm" : "Confirmar",
    "Settings" : "Settings",
    "Label" : "Etiqueta",
    "Enable" : "Activar",
    "Disable" : "Desactivar"
},
"nplurals=2; plural=(n != 1);");

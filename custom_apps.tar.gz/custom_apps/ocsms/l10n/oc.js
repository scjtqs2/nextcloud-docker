OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "Anullar",
    "Settings" : "Paramètres"
},
"nplurals=2; plural=(n > 1);");

OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "বাতির",
    "Settings" : "সেটিংস",
    "Enable" : "সক্রিয় ",
    "Disable" : "নিষ্ক্রিয়"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Telefoniga Sünkroniseerimine",
    "Cancel" : "Loobu",
    "Confirm" : "Kinnita",
    "Settings" : "Seaded",
    "Enable" : "Lülita sisse",
    "Disable" : "Lülita välja"
},
"nplurals=2; plural=(n != 1);");

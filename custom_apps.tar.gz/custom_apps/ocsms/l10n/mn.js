OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "болиулах",
    "Confirm" : "Батлах",
    "Settings" : "Тохиргоо",
    "Label" : "Хаяг"
},
"nplurals=2; plural=(n != 1);");

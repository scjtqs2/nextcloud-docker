OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "បោះបង់",
    "Settings" : "ការកំណត់",
    "Enable" : "បើក",
    "Disable" : "បិទ"
},
"nplurals=1; plural=0;");

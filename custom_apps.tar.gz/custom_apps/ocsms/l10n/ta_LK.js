OC.L10N.register(
    "ocsms",
    {
    "Cancel" : "இரத்து செய்க",
    "Settings" : "அமைப்புகள்",
    "Enable" : "இயலச்செய்",
    "Disable" : "இயலுமைப்ப"
},
"nplurals=2; plural=(n != 1);");

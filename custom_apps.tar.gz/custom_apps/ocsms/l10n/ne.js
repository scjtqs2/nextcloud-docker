OC.L10N.register(
    "ocsms",
    {
    "Settings" : "सेटिङ्हरू"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "ocsms",
    {
    "Phone Sync" : "Sincronizare telefon",
    "Cancel" : "Anulează",
    "Confirm" : "Confirmă",
    "Settings" : "Setări",
    "Label" : "Etichetă",
    "Enable" : "Activează",
    "Disable" : "Dezactivează"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");

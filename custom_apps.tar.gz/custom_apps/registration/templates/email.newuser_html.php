<?php
echo $l->t('A new user "%s" has created an account on %s', [$_['user'], $_['sitename']]);

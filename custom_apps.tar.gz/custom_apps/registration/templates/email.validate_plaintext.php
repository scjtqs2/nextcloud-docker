<?php
echo $l->t("To create a new account on %s, just click the following link:", [$_['sitename']]);
echo "\n\n".$_['link'];
